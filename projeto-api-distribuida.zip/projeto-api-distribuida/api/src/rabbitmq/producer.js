const { getCanal, FILA_NOTIFICACOES, FILA_AUDITORIA } = require('../config/rabbitmq');

/**
 * Publica um evento de notificação (ex: usuário criado)
 */
async function publicarNotificacao(evento) {
  try {
    const canal = await getCanal();
    const payload = Buffer.from(JSON.stringify(evento));
    canal.sendToQueue(FILA_NOTIFICACOES, payload, { persistent: true });
    console.log('[Producer] Notificação publicada:', evento.tipo);
  } catch (err) {
    console.error('[Producer] Erro ao publicar notificação:', err.message);
  }
}

/**
 * Publica um evento de auditoria (toda operação de escrita: create/update/delete)
 */
async function publicarAuditoria(evento) {
  try {
    const canal = await getCanal();
    const payload = Buffer.from(JSON.stringify(evento));
    canal.sendToQueue(FILA_AUDITORIA, payload, { persistent: true });
    console.log('[Producer] Auditoria publicada:', evento.acao);
  } catch (err) {
    console.error('[Producer] Erro ao publicar auditoria:', err.message);
  }
}

module.exports = { publicarNotificacao, publicarAuditoria };
