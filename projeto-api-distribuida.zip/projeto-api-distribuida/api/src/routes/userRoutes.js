const express = require('express');
const {
  criarUsuario,
  listarUsuarios,
  buscarUsuario,
  atualizarUsuario,
  removerUsuario,
} = require('../controllers/userController');

const router = express.Router();

router.post('/', criarUsuario);
router.get('/', listarUsuarios);
router.get('/:id', buscarUsuario);
router.put('/:id', atualizarUsuario);
router.delete('/:id', removerUsuario);

module.exports = router;
