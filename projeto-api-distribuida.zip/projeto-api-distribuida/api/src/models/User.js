const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    nome: {
      type: String,
      required: [true, 'O campo nome é obrigatório'],
      trim: true,
    },
    email: {
      type: String,
      required: [true, 'O campo email é obrigatório'],
      unique: true,
      lowercase: true,
      trim: true,
    },
    senha: {
      type: String,
      required: [true, 'O campo senha é obrigatório'],
      select: false, // nunca retorna a senha por padrão nas queries
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
