require('dotenv').config();

const app = require('./app');
const connectDB = require('./config/db');
const { getCanal } = require('./config/rabbitmq');
const iniciarConsumerNotificacoes = require('./rabbitmq/consumers/notificacoesConsumer');
const iniciarConsumerAuditoria = require('./rabbitmq/consumers/auditoriaConsumer');

const PORT = process.env.PORT || 3000;
const INSTANCE_ID = process.env.INSTANCE_ID || 'api-1';

async function iniciar() {
  await connectDB();
  await getCanal(); // garante conexão e filas criadas antes de subir os consumers

  await iniciarConsumerNotificacoes();
  await iniciarConsumerAuditoria();

  app.listen(PORT, () => {
    console.log(`[Server] Instância "${INSTANCE_ID}" rodando na porta ${PORT}`);
  });
}

iniciar().catch((err) => {
  console.error('[Server] Erro fatal ao iniciar a aplicação:', err);
  process.exit(1);
});
