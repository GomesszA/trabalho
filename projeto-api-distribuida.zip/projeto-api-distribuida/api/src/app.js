const express = require('express');
const userRoutes = require('./routes/userRoutes');

const app = express();

app.use(express.json());

// Identifica qual instância respondeu — útil para ver o load balancing funcionando
app.use((req, res, next) => {
  res.setHeader('X-Instance-Id', process.env.INSTANCE_ID || 'desconhecida');
  next();
});

app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', instancia: process.env.INSTANCE_ID || 'desconhecida' });
});

app.use('/usuarios', userRoutes);

module.exports = app;
