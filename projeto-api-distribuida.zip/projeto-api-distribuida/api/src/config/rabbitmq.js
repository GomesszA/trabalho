const amqp = require('amqplib');

const RABBIT_URL = process.env.RABBITMQ_URL || 'amqp://rabbitmq:5672';

const FILA_NOTIFICACOES = 'fila.notificacoes';
const FILA_AUDITORIA = 'fila.auditoria';

let canalCache = null;

async function conectar() {
  const maxTentativas = 10;
  let tentativa = 0;

  while (tentativa < maxTentativas) {
    try {
      const conexao = await amqp.connect(RABBIT_URL);
      const canal = await conexao.createChannel();

      // Garante que as duas filas existem antes de qualquer publish/consume
      await canal.assertQueue(FILA_NOTIFICACOES, { durable: true });
      await canal.assertQueue(FILA_AUDITORIA, { durable: true });

      console.log('[RabbitMQ] Conectado e filas declaradas com sucesso.');
      return canal;
    } catch (err) {
      tentativa += 1;
      console.log(`[RabbitMQ] Tentativa ${tentativa}/${maxTentativas} falhou: ${err.message}`);
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }

  throw new Error('[RabbitMQ] Não foi possível conectar após várias tentativas.');
}

async function getCanal() {
  if (!canalCache) {
    canalCache = await conectar();
  }
  return canalCache;
}

module.exports = {
  getCanal,
  FILA_NOTIFICACOES,
  FILA_AUDITORIA,
};
