const mongoose = require('mongoose');

async function connectDB() {
  const uri = process.env.MONGO_URI || 'mongodb://mongo:27017/usuarios_db';

  // Retry simples, útil porque o container do Mongo pode demorar a subir
  const maxTentativas = 10;
  let tentativa = 0;

  while (tentativa < maxTentativas) {
    try {
      await mongoose.connect(uri);
      console.log(`[MongoDB] Conectado com sucesso em ${uri}`);
      return;
    } catch (err) {
      tentativa += 1;
      console.log(`[MongoDB] Tentativa ${tentativa}/${maxTentativas} falhou: ${err.message}`);
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }

  throw new Error('[MongoDB] Não foi possível conectar após várias tentativas.');
}

module.exports = connectDB;
