const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { publicarNotificacao, publicarAuditoria } = require('../rabbitmq/producer');

// CREATE
async function criarUsuario(req, res) {
  try {
    const { nome, email, senha } = req.body;

    if (!nome || !email || !senha) {
      return res.status(400).json({ erro: 'nome, email e senha são obrigatórios.' });
    }

    const senhaHash = await bcrypt.hash(senha, 10);
    const usuario = await User.create({ nome, email, senha: senhaHash });

    await publicarNotificacao({ tipo: 'usuario_criado', userId: usuario._id, email: usuario.email });
    await publicarAuditoria({ acao: 'CREATE', recurso: 'usuario', userId: usuario._id, data: new Date().toISOString() });

    return res.status(201).json({
      id: usuario._id,
      nome: usuario.nome,
      email: usuario.email,
      createdAt: usuario.createdAt,
    });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ erro: 'Já existe um usuário com esse email.' });
    }
    return res.status(500).json({ erro: err.message });
  }
}

// READ (lista todos)
async function listarUsuarios(req, res) {
  try {
    const usuarios = await User.find().select('-senha');
    return res.status(200).json(usuarios);
  } catch (err) {
    return res.status(500).json({ erro: err.message });
  }
}

// READ (busca por id)
async function buscarUsuario(req, res) {
  try {
    const usuario = await User.findById(req.params.id).select('-senha');
    if (!usuario) {
      return res.status(404).json({ erro: 'Usuário não encontrado.' });
    }
    return res.status(200).json(usuario);
  } catch (err) {
    return res.status(500).json({ erro: err.message });
  }
}

// UPDATE
async function atualizarUsuario(req, res) {
  try {
    const { nome, email, senha } = req.body;
    const dadosAtualizados = {};

    if (nome) dadosAtualizados.nome = nome;
    if (email) dadosAtualizados.email = email;
    if (senha) dadosAtualizados.senha = await bcrypt.hash(senha, 10);

    const usuario = await User.findByIdAndUpdate(req.params.id, dadosAtualizados, {
      new: true,
      runValidators: true,
    }).select('-senha');

    if (!usuario) {
      return res.status(404).json({ erro: 'Usuário não encontrado.' });
    }

    await publicarAuditoria({ acao: 'UPDATE', recurso: 'usuario', userId: usuario._id, data: new Date().toISOString() });

    return res.status(200).json(usuario);
  } catch (err) {
    return res.status(500).json({ erro: err.message });
  }
}

// DELETE
async function removerUsuario(req, res) {
  try {
    const usuario = await User.findByIdAndDelete(req.params.id);

    if (!usuario) {
      return res.status(404).json({ erro: 'Usuário não encontrado.' });
    }

    await publicarAuditoria({ acao: 'DELETE', recurso: 'usuario', userId: usuario._id, data: new Date().toISOString() });

    return res.status(204).send();
  } catch (err) {
    return res.status(500).json({ erro: err.message });
  }
}

module.exports = {
  criarUsuario,
  listarUsuarios,
  buscarUsuario,
  atualizarUsuario,
  removerUsuario,
};
