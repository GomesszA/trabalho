const { getCanal, FILA_NOTIFICACOES } = require('../../config/rabbitmq');

async function iniciarConsumerNotificacoes() {
  const canal = await getCanal();

  canal.consume(FILA_NOTIFICACOES, (msg) => {
    if (!msg) return;

    const evento = JSON.parse(msg.content.toString());
    // Aqui simulamos o envio de uma notificação (ex: e-mail de boas-vindas)
    console.log(`[Consumer:Notificacoes] Evento "${evento.tipo}" recebido para o usuário ${evento.email || evento.userId}`);
    console.log('[Consumer:Notificacoes] -> Simulando envio de notificação...');

    canal.ack(msg);
  });

  console.log('[Consumer:Notificacoes] Aguardando mensagens na fila.notificacoes...');
}

module.exports = iniciarConsumerNotificacoes;
