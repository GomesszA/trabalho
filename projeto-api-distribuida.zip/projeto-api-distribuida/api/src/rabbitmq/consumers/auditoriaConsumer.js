const { getCanal, FILA_AUDITORIA } = require('../../config/rabbitmq');

async function iniciarConsumerAuditoria() {
  const canal = await getCanal();

  canal.consume(FILA_AUDITORIA, (msg) => {
    if (!msg) return;

    const evento = JSON.parse(msg.content.toString());
    // Aqui registramos o log de auditoria (poderia ir para outra collection, arquivo, etc.)
    console.log(
      `[Consumer:Auditoria] Ação "${evento.acao}" no recurso "${evento.recurso}" (id: ${evento.userId}) em ${evento.data}`
    );

    canal.ack(msg);
  });

  console.log('[Consumer:Auditoria] Aguardando mensagens na fila.auditoria...');
}

module.exports = iniciarConsumerAuditoria;
